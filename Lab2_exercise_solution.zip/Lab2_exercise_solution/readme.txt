This is an example of Lab2 exercise solution.

1. You need to go into ScalableML directory, which has been downloaded from GitHub.

2. Put three .py files into Code folder

3. In the .py files, change your username in the SparkSession builder part.

4. Put Lab2_Exercise.sh into HPC folder and set the python file to run

5. Then 'cd HPC' folder and run 'qsub Lab2_Exercise.sh'

5. Output file will be in the Output folder.
