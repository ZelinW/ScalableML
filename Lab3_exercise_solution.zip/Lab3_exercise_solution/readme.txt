This is an example of Lab3 exercise solution.

1. You need to go into ScalableML directory, which has been downloaded from GitHub. Do 
1a. "cd Data"
1b. "wget http://files.grouplens.org/datasets/movielens/ml-latest-small.zip"
1c. "unzip ml-latest-small.zip"
1d. "cd .."

2. Put .py file into Code folder

3. In the .py file, change your username in the SparkSession builder part.

4. Put Lab3_Exercise.sh into HPC folder.

5. Then 'cd HPC' folder and run 'qsub Lab3_Exercise.sh'

5. Output file will be in the Output folder.
