This is an example of Lab1 exercise solution.

1. You need to go into ScalableMachineLearning directory, which has been downloaded from GitHub.

2. Put Lab_1_Exercise_Solution.py file into Code folder

3. Put Lab1_Exercise.sh into HPC folder

4. Then 'cd HPC' filter and run 'qsub Lab1_Exercise.sh'

5. Output file will be appearing in the Output folder.
